﻿function Get-FileInfoOnContent {
<#
.SYNOPSIS
Get file info based on content .
.DESCRIPTION
This command will files in a directory based on a filter and pattern and return the files that have that pattern.
.PARAMETER Filepath
The path to the files that will be queried.
.PARAMETER Pattern
The pattern to be searched for in the files
.PARAMETER Filter
The filter to filter out file types, i.e (*.md)

.EXAMPLE
PS C:\> Get-FileNameOnContent -filepath C:\users\gwallace\azure-content-pr -pattern application-gateway -filter "*.md" 

Filename   : application-gateway-create-gateway-arm-template.md
LineNumber : 6
Matches    : {application-gateway}
Path       : C:\users\gwallace\azure-content-pr\articles\application-gateway\application-gateway-create-gateway-arm-template.md
Pattern    : application-gateway
IgnoreCase : True

Filename   : application-gateway-create-gateway-arm.md
LineNumber : 5
Matches    : {application-gateway}
Path       : C:\users\gwallace\azure-content-pr\articles\application-gateway\application-gateway-create-gateway-arm.md
Pattern    : application-gateway
IgnoreCase : True

.Notes
Last Updated: August 24, 2016
Version     : 0.1


#>

[cmdletbinding()]
param(
[ValidateNotNullorEmpty()]
[Parameter(Mandatory=$True,Position=1)]
[string]$Filepath,
[Parameter(Mandatory=$True,Position=2)]
[ValidateNotNullorEmpty()]
[array]$Pattern,
[string]$Filter
)

$files = Get-ChildItem -Path "$filepath" -Filter $filter -Recurse

foreach ($file in $files | Select-String -pattern $pattern -List) 
{

$obj = new-object psobject
$obj | add-member noteproperty Filename ($file.Filename)
# $obj | add-member noteproperty Line ($file.Line)
$obj | add-member noteproperty LineNumber ($file.LineNumber)
$obj | add-member noteproperty Matches ($file.Matches)
$obj | add-member noteproperty Path ($file.Path)
$obj | add-member noteproperty Pattern ($file.Pattern)
$obj | add-member noteproperty IgnoreCase ($file.IgnoreCase)

write-output $obj

}
}
function Add-BordertoImage
{
[cmdletbinding()]
param(
[ValidateNotNullorEmpty()]
[Parameter(Mandatory=$True,Position=1)]
[string]$filename)
Add-Type -AssemblyName System.Drawing


$png = [System.Drawing.Image]::FromFile($filename)
$brushFg = [System.Drawing.Color]::FromArgb(195,195,195)
$pen = New-Object System.Drawing.Pen($brushFg)
$graphics = [System.Drawing.Graphics]::FromImage($png) 
$array = @()
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.x,$graphics.VisibleClipBounds.x)
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.x,$graphics.VisibleClipBounds.Right)
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.Right,$graphics.VisibleClipBounds.Bottom)
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.y,$graphics.VisibleClipBounds.Bottom)

$graphics.DrawRectangle($pen,$graphics.VisibleClipBounds.x,$graphics.VisibleClipBounds.x,($graphics.VisibleClipBounds.Right - 1),($graphics.VisibleClipBounds.Bottom - 1))

$ms = new-object System.IO.MemoryStream
$png.Save($ms,[System.Drawing.Imaging.ImageFormat]::png)
#Start-Sleep -Milliseconds 30

$graphics.Dispose()
$png.Dispose()
$newpng = [System.Drawing.Image]::FromStream($ms)
$newpng.Save($filename);
}

Export-ModuleMember -Function "*"


