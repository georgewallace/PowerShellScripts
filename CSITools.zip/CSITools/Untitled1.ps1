﻿function Add-BordertoImage
{
params($filename)
Add-Type -AssemblyName System.Drawing
$filename2 = "c:\users\gwallace\desktop\figure1-1.png"
$filename = "c:\users\gwallace\desktop\figure1.png"
$png = New-Object System.Drawing.Bitmap $filename

$brushFg = [System.Drawing.Color]::FromArgb(195,195,195)
#$brushFg = [System.Drawing.Brushes]::Yellow
$pen = New-Object System.Drawing.Pen($brushFg)
$graphics = [System.Drawing.Graphics]::FromImage($png) 
$array = @()
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.x,$graphics.VisibleClipBounds.x)
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.x,$graphics.VisibleClipBounds.Right)
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.Right,$graphics.VisibleClipBounds.Bottom)
$array += new-object System.Drawing.Point($graphics.VisibleClipBounds.y,$graphics.VisibleClipBounds.Bottom)

$graphics.DrawRectangle($pen,$graphics.VisibleClipBounds.x,$graphics.VisibleClipBounds.x,($graphics.VisibleClipBounds.Right - 1),($graphics.VisibleClipBounds.Bottom - 1))
#$graphics.DrawLines($pen,$array)

$graphics.Dispose()
$png.Save($filename) 
}
Invoke-Item $filename2