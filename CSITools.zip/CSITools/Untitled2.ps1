﻿<#
.SYNOPSIS
	This script adds an authentication certificate to an AppGW.  This is used for Https to the backend servers.
	
.DESCRIPTION
	This script adds an authentication certificate to an AppGW.  This is used for Https to the backend servers.
	
.NOTES
	Author: Ed Mondek
	Date: 08/29/2016
	Revision: 1.0

.CHANGELOG
    1.0  08/29/2016  Ed Mondek  Initial commit
#>

# Sign in to your Azure account
Login-AzureRmAccount

$VerbosePreference = "Continue"

# Initialize variables
$subscriptionName = "Microsoft Azure Internal Consumption"
$location = "West US"
$path = "C:\Users\gwallace\OneDrive - Microsoft\CSI\AppGateway"

# Set the current subscription
Select-AzureRmSubscription -SubscriptionName $subscriptionName

# Get the existing AppGW
$rgName = "ContosoAppGatewayRG"
$appGwName = "ContosoAppGateway"

New-AzureRmResourceGroup -Name $rgName -location "West US"
Publish-AzureRmVMDscConfiguration "C:\Users\gwallace\OneDrive - Microsoft\CSI\AppGateway\WebServerConfig.ps1.zip" -ResourceGroupName $rgName -StorageAccountName $storageAcc.StorageAccountName -force

$subnet = New-AzureRmVirtualNetworkSubnetConfig -Name subnet01 -AddressPrefix 10.0.0.0/24
$subnet2 = New-AzureRmVirtualNetworkSubnetConfig -Name subnet02 -AddressPrefix 10.0.1.0/24
$subnet3 = New-AzureRmVirtualNetworkSubnetConfig -Name subnet03 -AddressPrefix 10.0.2.0/24
$vnet = New-AzureRmVirtualNetwork -Name appgwvnet -ResourceGroupName $rgName -Location "West US" -AddressPrefix 10.0.0.0/16 -Subnet $subnet,$subnet2,$subnet3
$subnet=$vnet.Subnets[0]

$storageAcc = New-AzureRmStorageAccount -ResourceGroupName $rgName -Name "appgatewaytest" -SkuName Standard_LRS -Location "West US"
$storageAcc = Get-AzureRmStorageAccount -ResourceGroupName $rgName -Name "appgatewaytest"
$locName = "westus"
$nicName = "mynic1"
$nic = New-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $rgName -Location $locName -SubnetId $vnet.Subnets[1].Id -PrivateIpAddress 10.0.1.68
$nic2 = New-AzureRmNetworkInterface -Name "mynic2" -ResourceGroupName $rgName -Location $locName -SubnetId $vnet.Subnets[1].Id -PrivateIpAddress 10.0.1.68
$cred = Get-Credential -UserName gwallace -Message "enter info"

$vmName = "myvm1"
$vm = New-AzureRmVMConfig -VMName $vmName -VMSize "Standard_A1"
$compName = "myvm1"
$vm = Set-AzureRmVMOperatingSystem -VM $vm -Windows -ComputerName $compName -Credential $cred -ProvisionVMAgent -EnableAutoUpdate
$vm = Set-AzureRmVMSourceImage -VM $vm -PublisherName MicrosoftWindowsServer -Offer WindowsServer -Skus 2012-R2-Datacenter -Version "latest"
$vm = Add-AzureRmVMNetworkInterface -VM $vm -Id $nic.Id
$blobPath = "vhds/WindowsVMosDisk.vhd"
$osDiskUri = $storageAcc.PrimaryEndpoints.Blob.ToString() + $blobPath
$diskName = "windowsvmosdisk"
$vm = Set-AzureRmVMOSDisk -VM $vm -Name $diskName -VhdUri $osDiskUri -CreateOption fromImage
$vm = Set-AzureRmVMDscExtension -ResourceGroupName $rgName -VMName $vm.Name -ArchiveBlobName "Sample.ps1.zip" -ArchiveStorageAccountName $storageAcc.StorageAccountName -ConfigurationName "WebServerConfig.ps1\\WebServerConfig" -Version "2.19" -Location "West US"


New-AzureRmVM -ResourceGroupName $rgName -Location $locName -VM $vm

$vmName = "myvm2"
$vm2 = New-AzureRmVMConfig -VMName $vmName -VMSize "Standard_A1"
$compName = "myvm2"
$vm2 = Set-AzureRmVMOperatingSystem -VM $vm2 -Windows -ComputerName $compName -Credential $cred -ProvisionVMAgent -EnableAutoUpdate
$vm2 = Set-AzureRmVMSourceImage -VM $vm2 -PublisherName MicrosoftWindowsServer -Offer WindowsServer -Skus 2012-R2-Datacenter -Version "latest"
$vm2 = Add-AzureRmVMNetworkInterface -VM $vm2 -Id $nic2.Id
$blobPath = "vhds/WindowsVMosDisk2.vhd"
$osDiskUri = $storageAcc.PrimaryEndpoints.Blob.ToString() + $blobPath
$diskName = "windowsvmosdisk"
$vm2 = Set-AzureRmVMOSDisk -VM $vm2 -Name $diskName -VhdUri $osDiskUri -CreateOption fromImage
New-AzureRmVM -ResourceGroupName $rgName -Location $locName -VM $vm2
$vm = Set-AzureRmVMDscExtension -ResourceGroupName $rgName -VMName $vm2.Name -ArchiveBlobName "Sample.ps1.zip" -ArchiveStorageAccountName $storageAcc.StorageAccountName -ConfigurationName "WebServerConfig.ps1\\WebServerConfig" -Version "2.19" -Location "West US"

$publicip = New-AzureRmPublicIpAddress -ResourceGroupName appgw-rg -name publicIP01 -location "West US" -AllocationMethod Dynamic
$gipconfig = New-AzureRmApplicationGatewayIPConfiguration -Name gatewayIP01 -Subnet $subnet
$pool = New-AzureRmApplicationGatewayBackendAddressPool -Name pool01 -BackendIPAddresses 10.0.1.68, 10.0.1.69
$poolSetting = New-AzureRmApplicationGatewayBackendHttpSettings -Name poolsetting01 -Port 443 -Protocol Http -CookieBasedAffinity Disabled
$fp = New-AzureRmApplicationGatewayFrontendPort -Name frontendport01  -Port 443
$fipconfig = New-AzureRmApplicationGatewayFrontendIPConfig -Name fipconfig01 -PublicIPAddress $publicip
$listener = New-AzureRmApplicationGatewayHttpListener -Name listener01  -Protocol Http -FrontendIPConfiguration $fipconfig -FrontendPort $fp
$rule = New-AzureRmApplicationGatewayRequestRoutingRule -Name rule01 -RuleType Basic -BackendHttpSettings $poolSetting -HttpListener $listener -BackendAddressPool $pool
$sku = New-AzureRmApplicationGatewaySku -Name Standard_Small -Tier Standard -Capacity 2
$appgw = New-AzureRmApplicationGateway -Name appgwtest -ResourceGroupName appgw-rg -Location "West US" -BackendAddressPools $pool -BackendHttpSettingsCollection $poolSetting -FrontendIpConfigurations $fipconfig  -GatewayIpConfigurations $gipconfig -FrontendPorts $fp -HttpListeners $listener -RequestRoutingRules $rule -Sku $sku

$appGw = Get-AzureRmApplicationGateway -ResourceGroupName $rgName -Name $appGwName

# Add an authentication certificate to the AppGW
# Here, authCertFilePath points to the .cer file of the certificate installed on the backend – i.e. we only want the public part of the certificate
$backendCertName = "backendCert01"
$authCertFilePath = $path + "cert.cer"
$appGw = Add-AzureRmApplicationGatewayAuthenticationCertificate -ApplicationGateway $appGw -Name $backendCertName -CertificateFile $authCertFilePath
$authCert = Get-AzureRmApplicationGatewayAuthenticationCertificate -ApplicationGateway $appGw -Name $backendCertName

# Add the backend certificate to the whitelist
$prodSrchBackendHttpSettingsName = "backendHttpSettingsPrdSearch"
$prodSrchBackendHttpSettingsProbeId = "/subscriptions/f865366b-adad-4e1d-855c-fce136ce95e2/resourceGroups/drsgrp-azsti05/providers/Microsoft.Network/applicationGateways/uextgw-azpse02/probes/probePrdSearch"
$prodSrchBackendHttpSetting = Set-AzureRmApplicationGatewayBackendHttpSettings -ApplicationGateway $appGw -Name $prodSrchBackendHttpSettingsName -Port 443 -Protocol "Https" -CookieBasedAffinity "Disabled" -AuthenticationCertificates $authCert -ProbeId $prodSrchBackendHttpSettingsProbeId

$storSrchBackendHttpSettingsName = "backendHttpSettingsStoreSearch"
$storSrchBackendHttpSettingsProbeId = "/subscriptions/f865366b-adad-4e1d-855c-fce136ce95e2/resourceGroups/drsgrp-azsti05/providers/Microsoft.Network/applicationGateways/uextgw-azpse02/probes/probeStoreSearch"
$storSrchBackendHttpSetting = Set-AzureRmApplicationGatewayBackendHttpSettings -ApplicationGateway $appGw -Name $storSrchBackendHttpSettingsName -Port 443 -Protocol "Https" -CookieBasedAffinity "Disabled" -AuthenticationCertificates $authCert -ProbeId $storSrchBackendHttpSettingsProbeId

$invBackendHttpSettingsName = "backendHttpSettingsInventory"
$invBackendHttpSettingsProbeId = "/subscriptions/f865366b-adad-4e1d-855c-fce136ce95e2/resourceGroups/drsgrp-azsti05/providers/Microsoft.Network/applicationGateways/uextgw-azpse02/probes/probeInventory"
$invBackendHttpSetting = Set-AzureRmApplicationGatewayBackendHttpSettings -ApplicationGateway $appGw -Name $invBackendHttpSettingsName -Port 443 -Protocol "Https" -CookieBasedAffinity "Disabled" -AuthenticationCertificates $authCert -ProbeId $invBackendHttpSettingsProbeId

$rootBackendHttpSettingsName = "backendHttpSettingsRoot"
$rootBackendHttpSettingsProbeId = "/subscriptions/f865366b-adad-4e1d-855c-fce136ce95e2/resourceGroups/drsgrp-azsti05/providers/Microsoft.Network/applicationGateways/uextgw-azpse02/probes/probeInventory"
$rootBackendHttpSetting = Set-AzureRmApplicationGatewayBackendHttpSettings -ApplicationGateway $appGw -Name $rootBackendHttpSettingsName -Port 443 -Protocol "Https" -CookieBasedAffinity "Disabled" -AuthenticationCertificates $authCert -ProbeId $rootBackendHttpSettingsProbeId

# Update the application gateway
Set-AzureRmApplicationGateway -ApplicationGateway $appGw 
